'use strict';

export MyComponent from './MyComponent/index';
export MyHeader from './Header/index';
export Menus from './Menus/index';
export SimpleReference from './SimpleReference/index';
export EditableCell from './EditTableCell/index';
export PageLoading from './Loading/index';
export LoadingTable from './LoadingTable/index';