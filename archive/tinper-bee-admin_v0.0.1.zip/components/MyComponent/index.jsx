import React, { Component } from 'react';

import './index.css';

class MyComponent extends Component {
  render() {
    return (
      <h1 className="demo">
        欢迎使用tinper-bee组件库。
      </h1>
    );
  }
}

export default MyComponent;
