import React, { Component } from 'react';
import { Table, Pagination } from 'tinper-bee';
import PageLoading from '../Loading/index';

import './index.css';

class LoadingTable extends Component{
    constructor(props){
        super(props);
        this.columns = [
            { title: '应用名称', dataIndex: 'name', key: 'name'},
            { title: '状态', dataIndex: 'status', key: 'status'},
            { title: '更新日期', dataIndex: 'date', key: 'date' },
            {title: '价格', dataIndex: 'price', key: 'price'},
        ];
        this.state = {
            data : [
                { name: '用友采购云', status: 'sale', date: '2017-04-19', price: '30555', key: '0' },
                { name: '用友HR云', status: 'hot', date: '2017-04-19', price: '68888', key: '1' },
                { name: '用友支付云', status: 'hot', date: '2017-04-19', price: '28889', key: '2' },
                { name: '用友财务云', status: 'test', date: '2017-04-19', price: '36666', key: '3' },
                { name: '用友建筑云', status: 'new', date: '2017-04-19', price: '25777', key: '4' }
            ],
            showLoading: true,
            activePage:1
        }
    }
    componentDidMount(){
        setTimeout( () => {
            this.setState({
                showLoading: false
            })
        }, 2000)
    }

    handleSelect = (eventKey) => {
        this.setState({
            activePage: eventKey
        });
    }

    render(){
        return(
            <div className="modal-container">
                <Table
                    columns={ this.columns }
                    data={ this.state.data }
                />
                <Pagination
                    first
                    last
                    prev
                    next
                    boundaryLinks
                    items={20}
                    maxButtons={5}
                    activePage={this.state.activePage}
                    onSelect={ this.handleSelect } />
                <PageLoading show={ this.state.showLoading } container={ this} />
            </div>

        )
    }
}

export default LoadingTable;